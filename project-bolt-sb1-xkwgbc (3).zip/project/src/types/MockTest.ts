export interface MockTest {
  id: string;
  title: string;
  description: string;
  duration: number; // in minutes
  numberOfQuestions: number;
  image: string;
}

export interface TestResult {
  testId: string;
  score: number;
  totalQuestions: number;
  correctAnswers: number;
  wrongAnswers: number;
  timeTaken: number;
}