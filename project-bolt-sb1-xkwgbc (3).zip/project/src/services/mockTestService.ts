import { supabase } from '../lib/supabase';
import type { MockTest } from '../types/MockTest';

export async function getMockTests(): Promise<MockTest[]> {
  const { data, error } = await supabase
    .from('mock_tests')
    .select(`
      id,
      title,
      description,
      duration,
      image_url,
      test_questions(count)
    `)
    .eq('is_active', true)
    .order('created_at', { ascending: false });

  if (error) throw error;

  return data.map(test => ({
    id: test.id,
    title: test.title,
    description: test.description,
    duration: test.duration,
    numberOfQuestions: test.test_questions[0].count,
    image: test.image_url,
  }));
}