import { supabase } from '../lib/supabase';
import type { Subject } from '../types/Subject';

export async function getSubjects(): Promise<Subject[]> {
  const { data, error } = await supabase
    .from('subjects')
    .select('*')
    .order('name');

  if (error) throw error;

  return data.map(subject => ({
    id: subject.id,
    name: subject.name,
    description: subject.description,
    image: subject.image_url,
    totalQuestions: subject.total_questions,
    topics: subject.topics,
  }));
}