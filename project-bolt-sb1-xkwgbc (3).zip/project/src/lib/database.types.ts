export interface Database {
  public: {
    Tables: {
      subjects: {
        Row: {
          id: string;
          name: string;
          description: string;
          image_url: string;
          total_questions: number;
          topics: string[];
          created_at: string;
        };
        Insert: Omit<Database['public']['Tables']['subjects']['Row'], 'id' | 'created_at'>;
        Update: Partial<Database['public']['Tables']['subjects']['Insert']>;
      };
      mock_tests: {
        Row: {
          id: string;
          title: string;
          description: string;
          duration: number;
          image_url: string;
          is_active: boolean;
          created_at: string;
        };
        Insert: Omit<Database['public']['Tables']['mock_tests']['Row'], 'id' | 'created_at'>;
        Update: Partial<Database['public']['Tables']['mock_tests']['Insert']>;
      };
      questions: {
        Row: {
          id: string;
          subject_id: string;
          question_text: string;
          options: string[];
          correct_answer: string;
          solution_text: string;
          created_at: string;
        };
        Insert: Omit<Database['public']['Tables']['questions']['Row'], 'id' | 'created_at'>;
        Update: Partial<Database['public']['Tables']['questions']['Insert']>;
      };
      test_questions: {
        Row: {
          id: string;
          test_id: string;
          question_id: string;
          question_order: number;
          created_at: string;
        };
        Insert: Omit<Database['public']['Tables']['test_questions']['Row'], 'id' | 'created_at'>;
        Update: Partial<Database['public']['Tables']['test_questions']['Insert']>;
      };
      user_test_attempts: {
        Row: {
          id: string;
          user_id: string;
          test_id: string;
          score: number;
          total_questions: number;
          correct_answers: number;
          time_taken: number | null;
          completed_at: string | null;
          created_at: string;
        };
        Insert: Omit<Database['public']['Tables']['user_test_attempts']['Row'], 'id' | 'created_at'>;
        Update: Partial<Database['public']['Tables']['user_test_attempts']['Insert']>;
      };
      user_answers: {
        Row: {
          id: string;
          attempt_id: string;
          question_id: string;
          selected_answer: string;
          is_correct: boolean;
          created_at: string;
        };
        Insert: Omit<Database['public']['Tables']['user_answers']['Row'], 'id' | 'created_at'>;
        Update: Partial<Database['public']['Tables']['user_answers']['Insert']>;
      };
    };
  };
}