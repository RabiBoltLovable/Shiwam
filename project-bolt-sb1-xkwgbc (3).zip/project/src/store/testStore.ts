import { create } from 'zustand';
import { supabase } from '../lib/supabase';
import type { Question, QuestionState } from '../types/Question';
import type { TestResult } from '../types/MockTest';

interface TestStore {
  questions: Question[];
  answers: Record<number, string>;
  showResults: boolean;
  testResult: TestResult | null;
  setQuestions: (questions: Question[]) => void;
  setAnswer: (index: number, answer: string) => void;
  submitTest: (testId: string) => Promise<void>;
  resetTest: () => void;
  fetchTestQuestions: (testId: string) => Promise<void>;
}

export const useTestStore = create<TestStore>((set, get) => ({
  questions: [],
  answers: {},
  showResults: false,
  testResult: null,

  setQuestions: (questions) => set({ questions }),

  setAnswer: (index, answer) => 
    set((state) => ({
      answers: { ...state.answers, [index]: answer }
    })),

  fetchTestQuestions: async (testId: string) => {
    const { data: testQuestions, error: questionsError } = await supabase
      .from('test_questions')
      .select(`
        question_id,
        questions (
          id,
          question_text,
          options,
          correct_answer,
          solution_text
        )
      `)
      .eq('test_id', testId)
      .order('question_order');

    if (questionsError) throw questionsError;

    const questions = testQuestions.map(({ questions }) => ({
      question: questions.question_text,
      options: questions.options,
      correct_answer: questions.correct_answer,
      solution: questions.solution_text,
    }));

    set({ questions });
  },

  submitTest: async (testId: string) => {
    const { questions, answers } = get();
    const totalQuestions = questions.length;
    const correctAnswers = questions.reduce((count, question, index) => {
      return count + (answers[index] === question.correct_answer ? 1 : 0);
    }, 0);

    const score = (correctAnswers / totalQuestions) * 100;

    // Create test attempt
    const { data: attempt, error: attemptError } = await supabase
      .from('user_test_attempts')
      .insert({
        test_id: testId,
        score,
        total_questions: totalQuestions,
        correct_answers: correctAnswers,
        completed_at: new Date().toISOString(),
      })
      .select()
      .single();

    if (attemptError) throw attemptError;

    // Save user answers
    const userAnswers = Object.entries(answers).map(([index, answer]) => ({
      attempt_id: attempt.id,
      question_id: questions[Number(index)].id,
      selected_answer: answer,
      is_correct: answer === questions[Number(index)].correct_answer,
    }));

    const { error: answersError } = await supabase
      .from('user_answers')
      .insert(userAnswers);

    if (answersError) throw answersError;

    const testResult: TestResult = {
      testId,
      score,
      totalQuestions,
      correctAnswers,
      wrongAnswers: totalQuestions - correctAnswers,
      timeTaken: 0, // TODO: Implement timer
    };

    set({ showResults: true, testResult });
  },

  resetTest: () => set({
    answers: {},
    showResults: false,
    testResult: null,
  }),
}));