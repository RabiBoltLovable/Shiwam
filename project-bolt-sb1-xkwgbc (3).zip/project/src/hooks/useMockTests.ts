import { useQuery } from '@tanstack/react-query';
import { getMockTests } from '../services/mockTestService';

export function useMockTests() {
  return useQuery({
    queryKey: ['mockTests'],
    queryFn: getMockTests,
  });
}