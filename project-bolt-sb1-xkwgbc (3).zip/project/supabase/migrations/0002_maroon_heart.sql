/*
  # Add sample data for medical exam practice app

  1. Sample Data
    - 5 subjects with topics
    - 5 mock tests
    - Questions for each subject
    - Test questions linking mock tests to questions
*/

-- Sample Subjects
INSERT INTO subjects (name, description, image_url, total_questions, topics) VALUES
('Anatomy', 'Study of human body structure and organization', 'https://images.unsplash.com/photo-1530026405186-ed1f139313f8?auto=format&fit=crop&q=80', 50, ARRAY['Musculoskeletal System', 'Cardiovascular System', 'Nervous System', 'Digestive System', 'Respiratory System']),
('Physiology', 'Study of body functions and mechanisms', 'https://images.unsplash.com/photo-1532187863486-abf9dbad1b69?auto=format&fit=crop&q=80', 45, ARRAY['Cell Physiology', 'Endocrine System', 'Blood', 'Immunity', 'Metabolism']),
('Pathology', 'Study of disease processes', 'https://images.unsplash.com/photo-1579165466741-7f35e4755660?auto=format&fit=crop&q=80', 40, ARRAY['Cell Injury', 'Inflammation', 'Neoplasia', 'Hemodynamic Disorders', 'Genetic Disorders']),
('Pharmacology', 'Study of drugs and their effects', 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?auto=format&fit=crop&q=80', 55, ARRAY['Drug Kinetics', 'Autonomic Drugs', 'Cardiovascular Drugs', 'Antimicrobials', 'CNS Drugs']),
('Biochemistry', 'Study of chemical processes in living organisms', 'https://images.unsplash.com/photo-1532634993-15f421e42ec0?auto=format&fit=crop&q=80', 35, ARRAY['Proteins', 'Enzymes', 'Metabolism', 'Molecular Biology', 'Nutrition']);

-- Sample Mock Tests
INSERT INTO mock_tests (title, description, duration, image_url) VALUES
('FMGE December 2023', 'Full mock test covering all subjects from the December 2023 exam pattern', 150, 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?auto=format&fit=crop&q=80'),
('FMGE June 2023', 'Comprehensive mock test based on June 2023 exam', 150, 'https://images.unsplash.com/photo-1579165466741-7f35e4755660?auto=format&fit=crop&q=80'),
('Quick Practice Test 1', 'Short practice test focusing on high-yield topics', 60, 'https://images.unsplash.com/photo-1532187863486-abf9dbad1b69?auto=format&fit=crop&q=80'),
('Subject-wise Test Bundle', 'Series of subject-focused tests', 120, 'https://images.unsplash.com/photo-1530026405186-ed1f139313f8?auto=format&fit=crop&q=80'),
('Final Preparation Test', 'Final comprehensive test before the actual exam', 150, 'https://images.unsplash.com/photo-1532634993-15f421e42ec0?auto=format&fit=crop&q=80');

-- Sample Questions for each subject
DO $$ 
DECLARE
  anatomy_id uuid;
  physiology_id uuid;
  pathology_id uuid;
  pharmacology_id uuid;
  biochemistry_id uuid;
  question_id uuid;
  test_id uuid;
BEGIN
  -- Get subject IDs
  SELECT id INTO anatomy_id FROM subjects WHERE name = 'Anatomy' LIMIT 1;
  SELECT id INTO physiology_id FROM subjects WHERE name = 'Physiology' LIMIT 1;
  SELECT id INTO pathology_id FROM subjects WHERE name = 'Pathology' LIMIT 1;
  SELECT id INTO pharmacology_id FROM subjects WHERE name = 'Pharmacology' LIMIT 1;
  SELECT id INTO biochemistry_id FROM subjects WHERE name = 'Biochemistry' LIMIT 1;

  -- Insert sample questions for each subject
  INSERT INTO questions (subject_id, question_text, options, correct_answer, solution_text) VALUES
  (anatomy_id, 'Which of the following muscles is responsible for plantar flexion of the foot?', 
   '["Tibialis anterior", "Gastrocnemius", "Peroneus longus", "Extensor digitorum longus"]',
   'Gastrocnemius',
   'The gastrocnemius muscle, along with the soleus, forms the calf muscle and is the primary muscle responsible for plantar flexion of the foot at the ankle joint.'),
   
  (physiology_id, 'What is the normal resting heart rate in adults?',
   '["40-60 beats per minute", "60-100 beats per minute", "100-120 beats per minute", "120-140 beats per minute"]',
   '60-100 beats per minute',
   'The normal resting heart rate for adults ranges from 60-100 beats per minute. This can vary based on factors such as age, physical fitness, and medical conditions.'),
   
  (pathology_id, 'Which of the following is a characteristic feature of acute inflammation?',
   '["Fibrosis", "Granuloma formation", "Vascular congestion", "Tissue atrophy"]',
   'Vascular congestion',
   'Vascular congestion is one of the cardinal signs of acute inflammation, along with increased blood flow and vascular permeability.'),
   
  (pharmacology_id, 'Which beta-blocker is cardioselective?',
   '["Propranolol", "Metoprolol", "Carvedilol", "Timolol"]',
   'Metoprolol',
   'Metoprolol is a cardioselective beta-blocker that primarily affects β1 receptors found in the heart.'),
   
  (biochemistry_id, 'Which enzyme catalyzes the first step of glycolysis?',
   '["Hexokinase", "Phosphofructokinase", "Pyruvate kinase", "Aldolase"]',
   'Hexokinase',
   'Hexokinase catalyzes the first step of glycolysis, converting glucose to glucose-6-phosphate using ATP as the phosphate donor.');

  -- Link questions to mock tests
  SELECT id INTO test_id FROM mock_tests WHERE title = 'FMGE December 2023' LIMIT 1;
  
  FOR question_id IN SELECT id FROM questions LOOP
    INSERT INTO test_questions (test_id, question_id, question_order)
    VALUES (test_id, question_id, (SELECT COALESCE(MAX(question_order), 0) + 1 
                                  FROM test_questions 
                                  WHERE test_id = test_id));
  END LOOP;
END $$;