/*
  # Add more sample data for medical exam practice app

  1. Additional Sample Data
    - 5 more questions for each subject
    - Links new questions to existing mock tests
*/

DO $$ 
DECLARE
  anatomy_id uuid;
  physiology_id uuid;
  pathology_id uuid;
  pharmacology_id uuid;
  biochemistry_id uuid;
  question_id uuid;
  test_id uuid;
BEGIN
  -- Get subject IDs
  SELECT id INTO anatomy_id FROM subjects WHERE name = 'Anatomy' LIMIT 1;
  SELECT id INTO physiology_id FROM subjects WHERE name = 'Physiology' LIMIT 1;
  SELECT id INTO pathology_id FROM subjects WHERE name = 'Pathology' LIMIT 1;
  SELECT id INTO pharmacology_id FROM subjects WHERE name = 'Pharmacology' LIMIT 1;
  SELECT id INTO biochemistry_id FROM subjects WHERE name = 'Biochemistry' LIMIT 1;

  -- Additional Anatomy Questions
  INSERT INTO questions (subject_id, question_text, options, correct_answer, solution_text) VALUES
  (anatomy_id, 'Which cranial nerve controls eye movement?',
   '["Optic nerve", "Oculomotor nerve", "Trochlear nerve", "Abducens nerve"]',
   'Oculomotor nerve',
   'The oculomotor nerve (CN III) controls most eye movements and eyelid elevation.'),
   
  (anatomy_id, 'What is the function of the coronary sinus?',
   '["Supplies blood to the heart", "Drains blood from the heart", "Produces hormones", "Stores blood"]',
   'Drains blood from the heart',
   'The coronary sinus is the main cardiac vein that collects blood from the heart muscle.'),
   
  (anatomy_id, 'Which structure connects the stomach to the duodenum?',
   '["Cardiac sphincter", "Pyloric sphincter", "Ileocecal valve", "Hepatic portal"]',
   'Pyloric sphincter',
   'The pyloric sphincter controls the passage of partially digested food from the stomach to the duodenum.'),
   
  (anatomy_id, 'What type of joint is the hip joint?',
   '["Hinge joint", "Ball and socket joint", "Pivot joint", "Saddle joint"]',
   'Ball and socket joint',
   'The hip joint is a ball and socket joint allowing movement in multiple planes.'),
   
  (anatomy_id, 'Which layer of the skin contains melanocytes?',
   '["Stratum corneum", "Dermis", "Epidermis", "Hypodermis"]',
   'Epidermis',
   'Melanocytes are located in the basal layer of the epidermis.');

  -- Additional Physiology Questions
  INSERT INTO questions (subject_id, question_text, options, correct_answer, solution_text) VALUES
  (physiology_id, 'What is the normal pH range of blood?',
   '["7.0-7.2", "7.35-7.45", "7.5-7.7", "6.8-7.0"]',
   '7.35-7.45',
   'Blood pH is tightly regulated between 7.35-7.45 to maintain proper cellular function.'),
   
  (physiology_id, 'Which hormone stimulates milk production?',
   '["Oxytocin", "Prolactin", "Estrogen", "Progesterone"]',
   'Prolactin',
   'Prolactin is responsible for milk production in mammary glands.'),
   
  (physiology_id, 'What is the function of surfactant in the lungs?',
   '["Increases surface tension", "Decreases surface tension", "Increases airway resistance", "Promotes inflammation"]',
   'Decreases surface tension',
   'Surfactant reduces surface tension in alveoli, preventing collapse during expiration.'),
   
  (physiology_id, 'Which part of the nephron is responsible for glucose reabsorption?',
   '["Proximal convoluted tubule", "Distal convoluted tubule", "Loop of Henle", "Collecting duct"]',
   'Proximal convoluted tubule',
   'The proximal convoluted tubule reabsorbs glucose through sodium-glucose cotransporters.'),
   
  (physiology_id, 'What is the main function of vitamin K?',
   '["Bone formation", "Blood clotting", "Immune function", "Energy metabolism"]',
   'Blood clotting',
   'Vitamin K is essential for the synthesis of several blood clotting factors.');

  -- Link new questions to mock tests
  FOR test_id IN SELECT id FROM mock_tests LOOP
    FOR question_id IN 
      SELECT id FROM questions 
      WHERE created_at > (SELECT MAX(created_at) FROM test_questions)
    LOOP
      INSERT INTO test_questions (test_id, question_id, question_order)
      VALUES (test_id, question_id, (
        SELECT COALESCE(MAX(question_order), 0) + 1 
        FROM test_questions 
        WHERE test_id = test_id
      ));
    END LOOP;
  END LOOP;
END $$;