/*
  # Initial Schema Setup for Medical Exam Practice App

  1. New Tables
    - subjects
      - Basic subject information
      - Contains medical subjects and their metadata
    
    - mock_tests
      - Full-length practice tests
      - Contains test metadata and configuration
    
    - questions
      - Question bank
      - Contains all questions with their options and solutions
    
    - test_questions
      - Links questions to mock tests
      - Allows reusing questions across different tests
    
    - user_test_attempts
      - Tracks user's test attempts
      - Stores scores and completion status
    
    - user_answers
      - Records user's answers for each attempt
      - Enables detailed analysis and solution review

  2. Security
    - Enable RLS on all tables
    - Policies for authenticated users to:
      - Read subjects and mock tests
      - Read questions during test
      - Submit answers
      - View their own test attempts and answers
*/

-- Create subjects table
CREATE TABLE subjects (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text NOT NULL,
  image_url text NOT NULL,
  total_questions integer DEFAULT 0,
  topics text[] DEFAULT '{}',
  created_at timestamptz DEFAULT now()
);

-- Create mock_tests table
CREATE TABLE mock_tests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text NOT NULL,
  duration integer NOT NULL, -- in minutes
  image_url text NOT NULL,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

-- Create questions table
CREATE TABLE questions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  subject_id uuid REFERENCES subjects(id),
  question_text text NOT NULL,
  options jsonb NOT NULL,
  correct_answer text NOT NULL,
  solution_text text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create test_questions table
CREATE TABLE test_questions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  test_id uuid REFERENCES mock_tests(id),
  question_id uuid REFERENCES questions(id),
  question_order integer NOT NULL,
  created_at timestamptz DEFAULT now(),
  UNIQUE(test_id, question_id)
);

-- Create user_test_attempts table
CREATE TABLE user_test_attempts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id),
  test_id uuid REFERENCES mock_tests(id),
  score numeric(5,2) DEFAULT 0,
  total_questions integer NOT NULL,
  correct_answers integer DEFAULT 0,
  time_taken integer, -- in minutes
  completed_at timestamptz,
  created_at timestamptz DEFAULT now()
);

-- Create user_answers table
CREATE TABLE user_answers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  attempt_id uuid REFERENCES user_test_attempts(id),
  question_id uuid REFERENCES questions(id),
  selected_answer text NOT NULL,
  is_correct boolean NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE subjects ENABLE ROW LEVEL SECURITY;
ALTER TABLE mock_tests ENABLE ROW LEVEL SECURITY;
ALTER TABLE questions ENABLE ROW LEVEL SECURITY;
ALTER TABLE test_questions ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_test_attempts ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_answers ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Allow public read access to subjects"
  ON subjects FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Allow public read access to mock tests"
  ON mock_tests FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Allow read access to questions during test"
  ON questions FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Allow read access to test questions"
  ON test_questions FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can view their own test attempts"
  ON user_test_attempts FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own test attempts"
  ON user_test_attempts FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can view their own answers"
  ON user_answers FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_test_attempts
      WHERE id = user_answers.attempt_id
      AND user_id = auth.uid()
    )
  );

CREATE POLICY "Users can submit their own answers"
  ON user_answers FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM user_test_attempts
      WHERE id = user_answers.attempt_id
      AND user_id = auth.uid()
    )
  );